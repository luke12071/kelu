# kelu设备监控仪表盘 (devdash) - ImmortalWrt 安装包

版本：1.0.1-1（架构 all，通用 x86_64 / aarch64 / mipsel 等）

## 文件说明
| 文件 | 说明 |
|---|---|
| `luci-app-devdash_1.0.1-1_all.ipk` | 实际功能包（脚本 + CGI + init.d），必须 |
| `app-meta-devdash_1.0.1-1_all.ipk` | iStore 元信息包（仅 iStoreOS 有用，ImmortalWrt 上可装可不装） |
| `install.sh` | 一键安装脚本（自动 opkg update、装依赖、装包、启服务、生成初始密码） |
| `devdash-使用说明.md` | 本文档 |

## 安装方法（ImmortalWrt）
方式一：本机下载后执行
```sh
cd /tmp
# 下载压缩包（把 <IP> 换成源设备 IP）：
curl -o devdash-immortalwrt.tar.gz http://<IP>/download/devdash/immortalwrt/devdash-immortalwrt.tar.gz
tar xzf devdash-immortalwrt.tar.gz
cd devdash-immortalwrt
sh install.sh
```

方式二：手动 opkg 安装
```sh
opkg update
opkg install luci-base tcpdump openssl-util
opkg install luci-app-devdash_1.0.1-1_all.ipk
```

## 依赖
`luci-base`、`tcpdump`、`openssl-util`（opkg install 会自动从 ImmortalWrt 源解析；
若目标源里 `openssl-util` 名称不同，可改为安装 `openssl-util` 或 `libopenssl`+`openssl-util`）。

## 功能
在线状态 / DNS 查询分析 / 抓包 / 在线时长排行 / 访问域名 Top5 / 网址屏蔽 /
主题背景 / 备份恢复 / 修改密码。访问：`http://<本机IP>/cgi-bin/devdash`

## 数据目录
默认 `/mnt/usb2_2-4/Public/device-monitor`；若目标机无此路径，编辑
`/etc/devdash.conf` 修改 `DEVDASH_BASE` / `DEVDASH_DNSDIR` 后
`/etc/init.d/devmon restart` 生效。
